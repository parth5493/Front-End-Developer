import users from './users'
import { combineReducers } from 'redux'

console.log("Called index of combineReducers");

export default combineReducers({users})