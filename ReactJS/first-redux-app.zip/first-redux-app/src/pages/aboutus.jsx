import React from 'react';

const AboutUs = () => {
    return (
        <>
            About Us
        </>
    );
};

export default AboutUs;