import React from 'react';

const UserDeskBoard = () => {
    return (
        <>
            User Desk Board
        </>
    );
};

export default UserDeskBoard;